package com.ghost.aitranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "GHOST AI Translator\n\nنمونه اولیه: تشخیص متن و پنجره ترجمه شناور"
            textSize = 20f
        })
        layout.addView(Button(this).apply {
            text = "۱) فعال‌کردن نمایش روی برنامه‌ها"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        layout.addView(Button(this).apply {
            text = "۲) شروع سرویس پنجره شناور"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "۳) اجازه ضبط صفحه (برای OCR)"
            setOnClickListener {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nتوجه: این نسخه هنوز موتور ترجمه و اتصال زنده MediaProjection را کامل ندارد. " +
                "هیچ متنی را به‌طور واقعی جایگزین نمی‌کند؛ فقط اسکلت امن پروژه و پنجره شناور را فراهم می‌کند."
            textSize = 14f
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK) {
            // Next development step: pass consent data to a foreground MediaProjection service.
            // Capture must remain user-visible and must stop when the user ends the session.
        }
    }
}
